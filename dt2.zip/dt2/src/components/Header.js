import React from 'react';

function Header() {
  return (
    <header className="header">
      <h1>공정현황 모니터링 시스템</h1>
    </header>
  );
}

export default Header;
